#ifndef NAMESURFERENTRYCPP
#define NAMESURFERENTRYCPP
#include <string>
#include <iostream>
#include <vector>
#include <fstream>
#include <sstream>
#include <cstdlib>
#include <cstdlib>
#include "NameSurferEntry.h"
using namespace std;

NameSurferEntry::NameSurferEntry(){
        name = "default";

}
//vector <int> year(12);//added in, still doesnt work
NameSurferEntry::NameSurferEntry(string line){//given a string, we should be able to parse the first word to name and the next 12 ints to the vector
        string i1,i2,i3,i4,i5,i6,i7,i8,i9,i10,i11;
        int q1,q2,q3,q4,q5,q6,q7,q8,q9,q10,q11;
        stringstream ss(line);
        getline(ss,name,' '); 
        
    /*
        getline(ss,i1,' ');
        cout << "i1 = " << i1 << endl;
        q1 = std::stoi(i1);
        cout << "q1 = " << q1 <<endl;
        
        getline(ss,i2,' ');
        cout << "i2 = " << i2 << endl;
        q2 = std::stoi(i2);
        cout << "q2 = " << q2 <<endl;
        
        getline(ss,i3,' ');
        cout << "i3 = " << i3 << endl;
        q3 = std::stoi(i3);
        cout << "q3 = " << q3 <<endl;
        
        getline(ss,i4,' ');
        cout << "i4 = " << i4 << endl;
        q4 = std::stoi(i4);
        cout << "q4 = " << q4 <<endl;
        
        getline(ss,i5,' ');
        cout << "i5 = " << i5 << endl;
        q5 = std::stoi(i5);
        cout << "q5 = " << q5 <<endl;
        
        getline(ss,i6,' ');
        cout << "i6 = " << i6 << endl;
        q6 = std::stoi(i6);
        cout << "q6 = " << q6 <<endl;
        
        getline(ss,i7,' ');
        cout << "i7 = " << i7 << endl;
        q7 = std::stoi(i7);
        cout << "q7 = " << q7 <<endl;
        
        getline(ss,i8,' ');
        cout << "i8 = " << i8 << endl;
        q8 = std::stoi(i8);
        cout << "q8 = " << q8 <<endl;
        
        getline(ss,i9,' ');
        cout << "i9 = " << i9 << endl;
        q9 = std::stoi(i9);
        cout << "q9 = " << q9 <<endl;
        
        getline(ss,i10,' ');
        cout << "i10 = " << i10 << endl;
        q10 = std::stoi(i10);
        cout << "q10 = " << q10 <<endl;
        
        getline(ss,i11,' ');
        cout << "i11 = " << i11 << endl;
        q11 = std::stoi(i11);
        cout << "q11 = " << q11 <<endl;
    */
        
        getline(ss,i1,' ');
        getline(ss,i2,' ');
        getline(ss,i3,' ');
        getline(ss,i4,' ');
        getline(ss,i5,' ');
        getline(ss,i6,' ');
        getline(ss,i7,' ');
        getline(ss,i8,' ');
        getline(ss,i9,' ');
        getline(ss,i10,' ');
        getline(ss,i11,' ');
        
        q1 = std::stoi(i1); 
        q2 = std::stoi(i2);
        q3 = std::stoi(i3);
        q4 = std::stoi(i4);
        q5 = std::stoi(i5);
        q6 = std::stoi(i6);
        q7 = std::stoi(i7);
        q8 = std::stoi(i8);
        q9 = std::stoi(i9);
        q10 = std::stoi(i10);
        q11 = std::stoi(i11);
        
        int nums[11] = {q1,q2,q3,q4,q5,q6,q7,q8,q9,q10,q11};
        for(int i = 1; i <=11;i++){ 
                year.push_back(nums[i-1]);
        }
        
}

void NameSurferEntry::setName(string n){
    name=n;
}

string NameSurferEntry::getName(){
        return name;
}

bool NameSurferEntry::empty(){ //change to actually check 
        return false;
}
int NameSurferEntry::getRank(int decade){//1900-2010 should be 12 decades
        if(decade == 1900)
            decade = 0;
        else if(decade == 1910)
            decade = 1;
        else if(decade == 1920)
            decade = 2;
        else if(decade == 1930)
            decade = 3;
        else if(decade == 1940)
            decade = 4;
        else if(decade == 1950)
            decade = 5;
        else if(decade == 1960)
            decade = 6;
        else if(decade == 1970)
            decade = 7;
        else if(decade == 1980)
            decade = 8;
        else if(decade == 1990)
            decade = 9;
        else if(decade == 2000)
            decade = 10;
            
        if(year.empty()){
                cout << "Empty vector\n";
                return 0;
        }
        else{
                return year.at(decade); //for int decade, return year's rank
        }
}
string stars(int rank){
    string ster = "";
    for(int i = 0; i < rank/50; i++){
        ster = ster + "*";
    }  
    string final = ster + "-"+std::to_string(rank);
    return final;
}
ostream& operator<<(ostream& out,NameSurferEntry temp){
    out << "1900" << stars((temp.getRank(0)))<< endl << "1910" << stars((temp.getRank(1)))<< endl << "1920" << stars((temp.getRank(2)))<< endl << "1930" << stars((temp.getRank(3)))<< endl << "1940" << stars((temp.getRank(4)))<< endl <<"1950" << stars((temp.getRank(5)))<< endl << "1960" << stars((temp.getRank(6)))<< endl << "1970" << stars((temp.getRank(7)))<< endl << "1980" << stars((temp.getRank(8)))<< endl << "1990" << stars((temp.getRank(9)))<< endl << "2000" << stars((temp.getRank(10)))<< endl;  
    return out;
}

bool NameSurferEntry::operator<(NameSurferEntry right){
        if(name < right.name)
                return true;
        else
                return false;
}
bool NameSurferEntry::operator<=(NameSurferEntry right){
        if(name <= right.name)
                return true;
        else
                return false;
}
bool NameSurferEntry::operator>(NameSurferEntry right){
        if(name > right.name)
                return true;
        else
                return false;
}
bool NameSurferEntry::operator>=(NameSurferEntry right){
        if(name >= right.name)
                return true;
        else
                return false;
}
bool NameSurferEntry::operator!=(NameSurferEntry right){
        if(name != right.name)
                return true;
        else
                return false;
}
bool NameSurferEntry::operator==(NameSurferEntry right){
if(name == right.name)
                return true;
        else
                return false;
}
#endif
