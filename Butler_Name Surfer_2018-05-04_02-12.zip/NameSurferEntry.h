#ifndef NAMESURFERENTRYH
#define NAMESURFERENTRYH
#include <string>
#include <iostream>
#include <vector>
using namespace std;

class NameSurferEntry{

        public:
                NameSurferEntry();
                NameSurferEntry(string line);
                void setName(string name);
                string getName();
                int getRank(int decade);
                bool empty();
                //friend overload for cout<<
                friend ostream& operator<<(ostream& out, NameSurferEntry temp);//following notes here
                string stars(int rank);
                bool operator<(NameSurferEntry right);//overload bools
                bool operator<=(NameSurferEntry right);
                bool operator>(NameSurferEntry right);
                bool operator>=(NameSurferEntry right);
                bool operator!=(NameSurferEntry right);
                bool operator==(NameSurferEntry right);
        private:
                vector<int> year;
                string name;
};
#endif

