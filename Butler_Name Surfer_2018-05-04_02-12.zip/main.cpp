#include <string>
#include <iostream>
#include "NameSurferEntry.h"
#include "NameSurferDataBase.h"
#include <vector>
using namespace std;

void printMenu();
string stars2(int rank);
/*
ostream& operator<<(ostream& out,NameSurferEntry temp){
    out << "1900" << stars((temp.getRank(0)))<< endl << "1910" << stars((temp.getRank(1)))<< endl << "1920" << stars((temp.getRank(2)))<< endl << "1930" << stars((temp.getRank(3)))<< endl << "1940" << stars((temp.getRank(4)))<< endl <<"1950" << stars((temp.getRank(5)))<< endl << "1960" << stars((temp.getRank(6)))<< endl << "1970" << stars((temp.getRank(7)))<< endl << "1980" << stars((temp.getRank(8)))<< endl << "1990" << stars((temp.getRank(9)))<< endl << "2000" << stars((temp.getRank(10)))<< endl;  
    return out;
}
*/

int main(){
        
        NameSurferDataBase base("NamesData.txt");
        NameSurferEntry temp;
        
        //temp=base.findEntry("Bobbye");
        //cout << "temp = Bobbye, getRank should be 687: ---> " << temp.getRank(1930) << endl;
        //base.getNameData("anything"); //just prints values
        //temp = base.findEntry("Zulma"); //TESTING
        
        int choice = 0;
        
        printMenu();
        cin >> choice;
        
        while(choice != 3){
            
        //cin >> choice; //test  
            if(choice == 1){
                cout << "Enter in a name: ";
                string nameth;
                cin >> nameth;
                cout << base.findEntry(nameth);
                cout << endl;
            }
            else if(choice == 2){
                std::vector<string> namevec;
                cout << "Enter a year: ";
                int yearnum;
                cin >> yearnum;
                cout << "Enter how many Names you want to compare: "; //create a vector of names, then for vector.size ask for each, then for each element in the vector use base.findEntry(vector[i]).getRank(yearnum)
                int namenum=1;
                cin >> namenum;
                
                for(int i = 0; i < namenum; i++){
                    cout << "Enter in a name: ";
                    string nameth;
                    cin >> nameth;
                    namevec.push_back(nameth);
                    //cout << stars((base.findEntry(nameth)).getRank(yearnum)) << endl;
                }
                for(int i = 0; i < namevec.size(); i++){ 
                    cout << stars2((base.findEntry(namevec[i])).getRank(yearnum)) << endl;    
                }
                cout << endl;
            }
            printMenu();
            cin >> choice;
        }

return 0;
}

string stars2(int rank){
    string ster = "";
    for(int i = 0; i < rank/50; i++){
        ster = ster + "*";
    }  
    string final = ster + "-"+std::to_string(rank);
    return final;
}

void printMenu(){
    cout << "Choose an option:\n";
    cout << "1: Enter a name to be searched\n";
    cout << "2: Enter a year\n";
    cout << "3: Quit\n";
}
