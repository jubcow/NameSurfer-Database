#include "NameSurferDataBase.h"
#include "NameSurferEntry.h"
#include "linked_list.h"
#include "single_node.h"
#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
using namespace std;


NameSurferDataBase::NameSurferDataBase(string filename){
        
        ifstream file(filename);
        while(file.good()){
                
                string line;
                getline (file,line);
                NameSurferEntry p(line); //creates a string of each line and an entry object for each to be added to the linkedlist of entries.
                
                //cout << "Adding " << p.getName() << " to the database...\n";
			    database.InsertInOrder(p); 
        }
}

void NameSurferDataBase::getNameData(string filename){ //meant to be what my consturctor already does, but printing is fun
        database.PrintAll();

}
//searches the database and returns a nameEntry
NameSurferEntry NameSurferDataBase::findEntry(string name){
        //cout << "Finding Entry...\n";
        NameSurferEntry temp;
        temp.setName(name);
        //cout<<"Before Search"<<temp.getName()<<endl;
     //   cout<< "Before Search: year 0: " << temp.getRank(0) << "   "<< "year 1: " << temp.getRank(1) <<"   "<<"year 2: " << temp.getRank(2) << endl;
        database.Search(temp); //Search is pass by reference
    //    cout<< "After Search: year 0: " << temp.getRank(0) << "   "<< "year 1: " << temp.getRank(1) <<"   "<<"year 2: " << temp.getRank(2) << endl;
        //cout<<temp<<endl<<endl;
        return temp;
}
























