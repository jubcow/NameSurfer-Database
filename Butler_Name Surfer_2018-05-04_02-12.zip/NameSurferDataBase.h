#include <string>
#include "NameSurferEntry.h"
//#include "NameSurferEntry.cpp"
#include "linked_list.h"
//#include "linked_list.cpp"
class NameSurferDataBase {

    public:
    
        //friend ostream& operator<<(ostream &out, NameSurferEntry temp); //no match for ‘operator<<’ error, idk if this will fix

        NameSurferDataBase(string filename);

        void getNameData(string filename);

        NameSurferEntry findEntry(string name);

    private:

        linked_list<NameSurferEntry> database;

};

